BIVAS SALARY MANAGER — সংশোধিত Android Source Project

এই ZIP-এর ভেতরের ফাইলগুলো সরাসরি GitHub repository-র মূল জায়গায় (root) আপলোড করবেন। BivasSalaryManager নামে আরেকটি বাইরের folder তৈরি করবেন না।

হিসাবের ভিত্তি: Basic ₹23,625; Daily ₹945; Hourly ₹105; স্বাভাবিক ডিউটি ৯ ঘণ্টা; ছুটি/Sunday বাদ দিয়ে মাসের Required Hours; সর্বোচ্চ ১৮ ঘণ্টা CL adjustment; তার বেশি ঘাটতি ₹১০৫/ঘণ্টা কাটা; Sunday/Holiday-তে কাজের সব ঘণ্টা OT; First Payment ও Second Payment আলাদা।

GitHub Actions workflow স্বয়ংক্রিয়ভাবে APK তৈরি করবে।
1) ZIP extract করুন।
2) extract করা folder-এর ভেতরের সব ফাইল GitHub repository-র root-এ upload করুন—বিশেষ করে .github folder-টিও।
3) GitHub > Actions > Build Android APK খুলুন।
4) Build সফল হলে run-এর Artifacts থেকে BIVAS-SALARY-MANAGER-APK download করুন।
5) ZIP খুলে app-debug.apk ফোনে install করুন।

এই ZIP-এ Android app-এর index.html asset-ও রাখা হয়েছে এবং workflow-তে Android SDK setup যোগ করা হয়েছে।
